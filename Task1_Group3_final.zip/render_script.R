
path="~/Documents/MESIO/Statistical Learning/5_Modelos_basados_en_arboles/Classification-tree-model"
rmarkdown::render("Task_1_v2.Rmd",output_file = paste0(path,"/Task1_Group3_pdf.pdf"))
rmarkdown::render("Task_1_v2.Rmd",output_file = paste0(path,"/Task1_Group3_html.html"))
